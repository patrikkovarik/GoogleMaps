<?php
$servername = "md347.wedos.net";
$username = "aYYCG9TX!";
$password = "";
$database = "d305942_kov";
$port = "3306";

// Create connection
$conn = new mysqli($servername, $username, $password, $database, $port);

// Check connection
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
echo "Connected successfully";


$markerQ = "SELECT * FROM markers ORDER BY id ASC";
$result = $conn->query($markerQ);



$allMarkers = $result->fetch_all();

?>



<!DOCTYPE html>
<html>
<body>
<h1>My First Google Map</h1>
<script
  src="https://code.jquery.com/jquery-3.6.1.js"
  integrity="sha256-3zlB5s2uwoUzrXK3BT7AX3FyvojsraNFxCc2vC/7pNI="
  crossorigin="anonymous"></script>
<script type="text/javascript"> 
        var markerArray = <?php echo json_encode($allMarkers);?> ; 
    </script>
<div id="googleMap" style="width:100%;height:800px;"></div>

<script src="index.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyAAUwUVrLzsuDtiPlFoGO-Wvz7HofexkG0&libraries=places&callback=myMap"></script>
</body>
</html>




<?php
$conn->close();
?>