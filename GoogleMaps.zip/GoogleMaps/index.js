var lat = {};
var lng = {};
var popis = {};

var uri = {};
var res = {};

$.ajax({
  type: "POST",
  url: res,
  data: {
    lat : 'lat',
    lng: 'lng',
    Popisek: 'popis'
  }
})

function myMap() {
  var mapProp= {
    center:new google.maps.LatLng(50.0754,14.4260),
    zoom:15,
    mapId: "56e73170c7176747",
  };
  var map = new google.maps.Map(document.getElementById("googleMap"),mapProp);

  function addMarker(props){
      var marker = new google.maps.Marker({
      position: props.coords,
      content: props.desc,
      map: map
    });

    if(props.desc){
      var infoWindow = new google.maps.InfoWindow({
        content: props.desc,
        width: 320
      });

      marker.addListener('click', function(){
        map.setZoom(15);
        map.panTo(this.getPosition());
        infoWindow.open(map, marker);
      });
    }
  }

  function loadMarkers(){
    var markers = markerArray;
    var getMaxId = markers.length;
    for (let i = 0; i < getMaxId; i++){
      addMarker({coords:{lat: Number(markers[i][1]), lng: Number(markers[i][2])}, 
                 desc: String(markers[i][3])});
    }
  }

  function typeDesc(){
    var description = prompt("Napiste popisek");
    popis = description;
    return description;
  }

  google.maps.event.addListener(map, 'click', function (e) {
    var location = e.latLng;
    lat = e.latLng.lat();
    lng = e.latLng.lng();
    addMarker({coords:location, desc: typeDesc()});
    uri = "index.php?lat=" + lat + "&lng=" + lng + "&Popisek=" + popis;
    res = encodeURI(uri);
    alert(res);
  });


  loadMarkers();
  
}











